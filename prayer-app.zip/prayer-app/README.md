# تطبيق مواقيت الصلاة 🕌

## الميزات
- ✅ مواقيت الصلاة الخمس حسب موقعك
- ✅ عداد تنازلي للصلاة القادمة
- ✅ إشعارات الأذان
- ✅ عداد التسبيح
- ✅ أذكار الصباح والمساء والنوم
- ✅ بوصلة القبلة
- ✅ التاريخ الهجري
- ✅ واجهة عربية RTL داكنة

## تشغيل التطبيق

### المتطلبات
- Node.js
- npm أو yarn

### التثبيت
```bash
npm install
npx expo start
```

### بناء APK حقيقي
```bash
npm install -g eas-cli
eas login
eas build --platform android --profile preview
```

## مصادر البيانات
- مواقيت الصلاة: [Aladhan API](https://aladhan.com/prayer-times-api)
- الأذكار: حصن المسلم
