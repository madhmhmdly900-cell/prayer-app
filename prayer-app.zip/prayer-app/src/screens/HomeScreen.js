import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, ActivityIndicator, Alert
} from 'react-native';
import * as Location from 'expo-location';
import * as Notifications from 'expo-notifications';

const COLORS = {
  primary: '#C9A84C',
  background: '#1A1A2E',
  card: '#16213E',
  text: '#FFFFFF',
  subtext: '#AAA',
  active: '#C9A84C',
};

const PRAYER_NAMES = {
  Fajr: 'الفجر',
  Sunrise: 'الشروق',
  Dhuhr: 'الظهر',
  Asr: 'العصر',
  Maghrib: 'المغرب',
  Isha: 'العشاء',
};

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export default function HomeScreen() {
  const [prayerTimes, setPrayerTimes] = useState(null);
  const [loading, setLoading] = useState(true);
  const [location, setLocation] = useState(null);
  const [nextPrayer, setNextPrayer] = useState(null);
  const [countdown, setCountdown] = useState('');
  const [cityName, setCityName] = useState('');
  const [hijriDate, setHijriDate] = useState('');

  useEffect(() => {
    getLocationAndPrayers();
  }, []);

  useEffect(() => {
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [prayerTimes]);

  const getLocationAndPrayers = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('تنبيه', 'يحتاج التطبيق إذن الموقع لعرض مواقيت الصلاة');
        setLoading(false);
        return;
      }
      const loc = await Location.getCurrentPositionAsync({});
      setLocation(loc.coords);

      const geo = await Location.reverseGeocodeAsync(loc.coords);
      if (geo[0]) setCityName(geo[0].city || geo[0].region || '');

      await fetchPrayerTimes(loc.coords.latitude, loc.coords.longitude);

      await Notifications.requestPermissionsAsync();
    } catch (e) {
      Alert.alert('خطأ', 'تعذر تحديد الموقع');
      setLoading(false);
    }
  };

  const fetchPrayerTimes = async (lat, lng) => {
    try {
      const today = new Date();
      const dateStr = `${today.getDate()}-${today.getMonth() + 1}-${today.getFullYear()}`;
      const res = await fetch(
        `https://api.aladhan.com/v1/timings/${dateStr}?latitude=${lat}&longitude=${lng}&method=4`
      );
      const data = await res.json();
      if (data.code === 200) {
        setPrayerTimes(data.data.timings);
        const hijri = data.data.date.hijri;
        setHijriDate(`${hijri.day} ${hijri.month.ar} ${hijri.year} هـ`);
        scheduleNotifications(data.data.timings);
      }
    } catch (e) {
      Alert.alert('خطأ', 'تعذر تحميل مواقيت الصلاة');
    } finally {
      setLoading(false);
    }
  };

  const scheduleNotifications = async (timings) => {
    await Notifications.cancelAllScheduledNotificationsAsync();
    const prayers = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
    const now = new Date();
    for (const prayer of prayers) {
      const [h, m] = timings[prayer].split(':').map(Number);
      const prayerDate = new Date();
      prayerDate.setHours(h, m, 0, 0);
      if (prayerDate > now) {
        await Notifications.scheduleNotificationAsync({
          content: {
            title: `حان وقت ${PRAYER_NAMES[prayer]}`,
            body: 'الصلاة خير من النوم',
            sound: true,
          },
          trigger: prayerDate,
        });
      }
    }
  };

  const updateCountdown = () => {
    if (!prayerTimes) return;
    const now = new Date();
    const prayers = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
    for (const prayer of prayers) {
      const [h, m] = prayerTimes[prayer].split(':').map(Number);
      const prayerDate = new Date();
      prayerDate.setHours(h, m, 0, 0);
      if (prayerDate > now) {
        setNextPrayer(prayer);
        const diff = prayerDate - now;
        const hours = Math.floor(diff / 3600000);
        const mins = Math.floor((diff % 3600000) / 60000);
        const secs = Math.floor((diff % 60000) / 1000);
        setCountdown(`${hours.toString().padStart(2,'0')}:${mins.toString().padStart(2,'0')}:${secs.toString().padStart(2,'0')}`);
        return;
      }
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={{ color: COLORS.text, marginTop: 10 }}>جاري تحميل مواقيت الصلاة...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 20 }}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.cityName}>{cityName}</Text>
        <Text style={styles.hijriDate}>{hijriDate}</Text>
        {nextPrayer && (
          <>
            <Text style={styles.nextPrayerLabel}>الصلاة القادمة</Text>
            <Text style={styles.nextPrayerName}>{PRAYER_NAMES[nextPrayer]}</Text>
            <Text style={styles.countdown}>{countdown}</Text>
          </>
        )}
      </View>

      {/* Prayer Times */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>مواقيت اليوم</Text>
        {prayerTimes && Object.entries(PRAYER_NAMES).map(([key, name]) => (
          <View
            key={key}
            style={[styles.prayerRow, nextPrayer === key && styles.activePrayer]}
          >
            <Text style={[styles.prayerTime, nextPrayer === key && { color: COLORS.background }]}>
              {prayerTimes[key]}
            </Text>
            <Text style={[styles.prayerName, nextPrayer === key && { color: COLORS.background }]}>
              {name}
            </Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: {
    backgroundColor: COLORS.card,
    padding: 24,
    alignItems: 'center',
    margin: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#333',
  },
  cityName: { color: COLORS.primary, fontSize: 18, fontWeight: 'bold' },
  hijriDate: { color: COLORS.subtext, fontSize: 14, marginTop: 4 },
  nextPrayerLabel: { color: COLORS.subtext, fontSize: 14, marginTop: 12 },
  nextPrayerName: { color: COLORS.text, fontSize: 32, fontWeight: 'bold' },
  countdown: { color: COLORS.primary, fontSize: 24, marginTop: 4 },
  section: { marginHorizontal: 16 },
  sectionTitle: { color: COLORS.subtext, fontSize: 14, marginBottom: 8, textAlign: 'right' },
  prayerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: COLORS.card,
    padding: 16,
    marginBottom: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#333',
  },
  activePrayer: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  prayerName: { color: COLORS.text, fontSize: 16, fontWeight: 'bold' },
  prayerTime: { color: COLORS.subtext, fontSize: 16 },
});
