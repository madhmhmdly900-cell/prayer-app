import React, { useState } from 'react';
import { View, Text, StyleSheet, Switch, TouchableOpacity, ScrollView } from 'react-native';

const METHODS = [
  { id: 4, name: 'أم القرى - السعودية' },
  { id: 2, name: 'رابطة العالم الإسلامي' },
  { id: 3, name: 'مجلس أمريكا الشمالية' },
  { id: 5, name: 'جامعة العلوم الإسلامية - كراتشي' },
];

export default function SettingsScreen() {
  const [notifications, setNotifications] = useState(true);
  const [selectedMethod, setSelectedMethod] = useState(4);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>الإشعارات</Text>
        <View style={styles.row}>
          <Switch
            value={notifications}
            onValueChange={setNotifications}
            trackColor={{ false: '#333', true: '#C9A84C' }}
            thumbColor={notifications ? '#FFF' : '#666'}
          />
          <Text style={styles.rowText}>تفعيل إشعارات الأذان</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>طريقة حساب مواقيت الصلاة</Text>
        {METHODS.map(method => (
          <TouchableOpacity
            key={method.id}
            onPress={() => setSelectedMethod(method.id)}
            style={styles.row}
          >
            <View style={[styles.radio, selectedMethod === method.id && styles.radioActive]} />
            <Text style={styles.rowText}>{method.name}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>عن التطبيق</Text>
        <Text style={styles.about}>تطبيق مواقيت الصلاة - الإصدار 1.0</Text>
        <Text style={styles.about}>بيانات الصلاة من Aladhan API</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1A1A2E' },
  section: {
    backgroundColor: '#16213E', margin: 16, borderRadius: 12,
    padding: 16, borderWidth: 1, borderColor: '#333',
  },
  sectionTitle: { color: '#C9A84C', fontSize: 16, fontWeight: 'bold', marginBottom: 12, textAlign: 'right' },
  row: {
    flexDirection: 'row-reverse', alignItems: 'center',
    paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#333',
  },
  rowText: { color: '#FFF', fontSize: 15, marginRight: 12, flex: 1, textAlign: 'right' },
  radio: {
    width: 20, height: 20, borderRadius: 10,
    borderWidth: 2, borderColor: '#C9A84C', marginLeft: 8,
  },
  radioActive: { backgroundColor: '#C9A84C' },
  about: { color: '#AAA', textAlign: 'right', marginBottom: 4 },
});
