import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { Magnetometer } from 'expo-sensors';
import * as Location from 'expo-location';

export default function QiblaScreen() {
  const [heading, setHeading] = useState(0);
  const [qiblaAngle, setQiblaAngle] = useState(0);
  const [loading, setLoading] = useState(true);

  const KAABA = { lat: 21.4225, lng: 39.8262 };

  useEffect(() => {
    getQibla();
    const sub = Magnetometer.addListener(data => {
      let angle = Math.atan2(data.y, data.x) * (180 / Math.PI);
      if (angle < 0) angle += 360;
      setHeading(angle);
    });
    Magnetometer.setUpdateInterval(100);
    return () => sub.remove();
  }, []);

  const getQibla = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const loc = await Location.getCurrentPositionAsync({});
      const { latitude, longitude } = loc.coords;

      const dLng = (KAABA.lng - longitude) * (Math.PI / 180);
      const lat1 = latitude * (Math.PI / 180);
      const lat2 = KAABA.lat * (Math.PI / 180);
      const y = Math.sin(dLng) * Math.cos(lat2);
      const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
      let angle = Math.atan2(y, x) * (180 / Math.PI);
      if (angle < 0) angle += 360;
      setQiblaAngle(angle);
    } catch (e) {
      Alert.alert('خطأ', 'تعذر تحديد اتجاه القبلة');
    } finally {
      setLoading(false);
    }
  };

  const needleRotation = qiblaAngle - heading;

  if (loading) return (
    <View style={[styles.container, { justifyContent: 'center' }]}>
      <ActivityIndicator size="large" color="#C9A84C" />
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>اتجاه القبلة</Text>
      <Text style={styles.subtitle}>الكعبة المشرفة - مكة المكرمة</Text>

      <View style={styles.compassContainer}>
        <View style={[styles.compass, { transform: [{ rotate: `${-heading}deg` }] }]}>
          {['N', 'E', 'S', 'W'].map((dir, i) => (
            <Text
              key={dir}
              style={[styles.direction, {
                transform: [{ rotate: `${i * 90}deg` }, { translateY: -80 }]
              }]}
            >
              {dir}
            </Text>
          ))}
        </View>

        <View style={[styles.needle, { transform: [{ rotate: `${needleRotation}deg` }] }]}>
          <Text style={styles.kaabaIcon}>🕋</Text>
        </View>
      </View>

      <Text style={styles.angle}>الزاوية: {Math.round(qiblaAngle)}°</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1A1A2E', alignItems: 'center', padding: 24 },
  title: { color: '#C9A84C', fontSize: 24, fontWeight: 'bold', marginBottom: 8 },
  subtitle: { color: '#AAA', fontSize: 14, marginBottom: 40 },
  compassContainer: { width: 250, height: 250, justifyContent: 'center', alignItems: 'center' },
  compass: {
    width: 200, height: 200, borderRadius: 100,
    borderWidth: 3, borderColor: '#C9A84C',
    backgroundColor: '#16213E',
    justifyContent: 'center', alignItems: 'center', position: 'absolute',
  },
  direction: { position: 'absolute', color: '#AAA', fontSize: 16, fontWeight: 'bold' },
  needle: { position: 'absolute', alignItems: 'center' },
  kaabaIcon: { fontSize: 40 },
  angle: { color: '#AAA', fontSize: 16, marginTop: 24 },
});
