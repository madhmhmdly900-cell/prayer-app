import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Vibration } from 'react-native';

const COLORS = {
  primary: '#C9A84C',
  background: '#1A1A2E',
  card: '#16213E',
  text: '#FFFFFF',
  subtext: '#AAA',
};

const TASBIH_OPTIONS = [
  { name: 'سبحان الله', target: 33 },
  { name: 'الحمد لله', target: 33 },
  { name: 'الله أكبر', target: 34 },
  { name: 'لا إله إلا الله', target: 100 },
  { name: 'أستغفر الله', target: 100 },
];

export default function TasbihScreen() {
  const [count, setCount] = useState(0);
  const [selected, setSelected] = useState(0);

  const tap = () => {
    Vibration.vibrate(30);
    setCount(c => c + 1);
  };

  const reset = () => {
    Vibration.vibrate([0, 50, 50, 50]);
    setCount(0);
  };

  const target = TASBIH_OPTIONS[selected].target;
  const progress = Math.min(count / target, 1);

  return (
    <View style={styles.container}>
      <View style={styles.selector}>
        {TASBIH_OPTIONS.map((opt, i) => (
          <TouchableOpacity
            key={i}
            onPress={() => { setSelected(i); setCount(0); }}
            style={[styles.optBtn, selected === i && styles.optBtnActive]}
          >
            <Text style={[styles.optText, selected === i && { color: COLORS.background }]}>
              {opt.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.dhikrName}>{TASBIH_OPTIONS[selected].name}</Text>
      <Text style={styles.target}>الهدف: {target}</Text>

      {/* Progress circle */}
      <View style={styles.progressContainer}>
        <View style={[styles.progressRing, { borderColor: count >= target ? '#4CAF50' : COLORS.primary }]}>
          <Text style={styles.countText}>{count}</Text>
          <Text style={styles.totalText}>/ {target}</Text>
        </View>
      </View>

      {count >= target && (
        <Text style={styles.doneText}>✓ اكتمل الذكر</Text>
      )}

      <TouchableOpacity style={styles.tapBtn} onPress={tap} activeOpacity={0.7}>
        <Text style={styles.tapBtnText}>اضغط للتسبيح</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.resetBtn} onPress={reset}>
        <Text style={styles.resetText}>إعادة تعيين</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1A1A2E', alignItems: 'center', padding: 16 },
  selector: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', marginBottom: 16 },
  optBtn: {
    borderWidth: 1, borderColor: '#C9A84C', borderRadius: 20,
    paddingHorizontal: 12, paddingVertical: 6, margin: 4,
  },
  optBtnActive: { backgroundColor: '#C9A84C' },
  optText: { color: '#C9A84C', fontSize: 12 },
  dhikrName: { color: '#FFF', fontSize: 22, fontWeight: 'bold', marginBottom: 4 },
  target: { color: '#AAA', fontSize: 14, marginBottom: 24 },
  progressContainer: { marginBottom: 24 },
  progressRing: {
    width: 180, height: 180, borderRadius: 90,
    borderWidth: 8, justifyContent: 'center', alignItems: 'center',
    backgroundColor: '#16213E',
  },
  countText: { color: '#FFF', fontSize: 52, fontWeight: 'bold' },
  totalText: { color: '#AAA', fontSize: 16 },
  doneText: { color: '#4CAF50', fontSize: 18, marginBottom: 16 },
  tapBtn: {
    backgroundColor: '#C9A84C', width: 200, height: 200,
    borderRadius: 100, justifyContent: 'center', alignItems: 'center',
    marginBottom: 20, elevation: 8,
  },
  tapBtnText: { color: '#1A1A2E', fontSize: 18, fontWeight: 'bold' },
  resetBtn: { borderWidth: 1, borderColor: '#666', borderRadius: 20, paddingHorizontal: 24, paddingVertical: 10 },
  resetText: { color: '#AAA', fontSize: 14 },
});
