import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';

const AZKAR = {
  morning: [
    { text: 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ', count: 1, ref: 'حصن المسلم' },
    { text: 'اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ', count: 1, ref: 'أبو داود' },
    { text: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ', count: 100, ref: 'مسلم' },
    { text: 'أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ', count: 3, ref: 'حصن المسلم' },
    { text: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ', count: 3, ref: 'حصن المسلم' },
  ],
  evening: [
    { text: 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ', count: 1, ref: 'حصن المسلم' },
    { text: 'اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ', count: 1, ref: 'أبو داود' },
    { text: 'اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ', count: 1, ref: 'البخاري' },
    { text: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ', count: 100, ref: 'مسلم' },
  ],
  sleep: [
    { text: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا', count: 1, ref: 'البخاري' },
    { text: 'اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ', count: 3, ref: 'أبو داود' },
    { text: 'سُبْحَانَ اللَّهِ', count: 33, ref: 'البخاري' },
    { text: 'الْحَمْدُ لِلَّهِ', count: 33, ref: 'البخاري' },
    { text: 'اللَّهُ أَكْبَرُ', count: 34, ref: 'البخاري' },
  ],
};

const TABS = [
  { key: 'morning', label: 'أذكار الصباح' },
  { key: 'evening', label: 'أذكار المساء' },
  { key: 'sleep', label: 'أذكار النوم' },
];

export default function AzkarScreen() {
  const [activeTab, setActiveTab] = useState('morning');
  const [counts, setCounts] = useState({});

  const tap = (index) => {
    const key = `${activeTab}-${index}`;
    setCounts(prev => ({ ...prev, [key]: (prev[key] || 0) + 1 }));
  };

  const getCount = (index) => counts[`${activeTab}-${index}`] || 0;

  return (
    <View style={styles.container}>
      <View style={styles.tabs}>
        {TABS.map(tab => (
          <TouchableOpacity
            key={tab.key}
            onPress={() => setActiveTab(tab.key)}
            style={[styles.tab, activeTab === tab.key && styles.activeTab]}
          >
            <Text style={[styles.tabText, activeTab === tab.key && styles.activeTabText]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView contentContainerStyle={{ padding: 16 }}>
        {AZKAR[activeTab].map((zikr, i) => (
          <TouchableOpacity key={i} onPress={() => tap(i)} style={styles.card}>
            <View style={styles.cardHeader}>
              <Text style={styles.ref}>{zikr.ref}</Text>
              <Text style={styles.countBadge}>{getCount(i)} / {zikr.count}</Text>
            </View>
            <Text style={styles.zikrText}>{zikr.text}</Text>
            {getCount(i) >= zikr.count && (
              <Text style={styles.done}>✓ اكتمل</Text>
            )}
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1A1A2E' },
  tabs: { flexDirection: 'row', backgroundColor: '#16213E', padding: 8 },
  tab: { flex: 1, padding: 10, alignItems: 'center', borderRadius: 8 },
  activeTab: { backgroundColor: '#C9A84C' },
  tabText: { color: '#AAA', fontSize: 12 },
  activeTabText: { color: '#1A1A2E', fontWeight: 'bold' },
  card: {
    backgroundColor: '#16213E', borderRadius: 12, padding: 16,
    marginBottom: 12, borderWidth: 1, borderColor: '#333',
  },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  ref: { color: '#C9A84C', fontSize: 12 },
  countBadge: { color: '#AAA', fontSize: 12 },
  zikrText: { color: '#FFF', fontSize: 18, lineHeight: 32, textAlign: 'right' },
  done: { color: '#4CAF50', textAlign: 'left', marginTop: 8, fontSize: 12 },
});
