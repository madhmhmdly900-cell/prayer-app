import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { I18nManager, StatusBar } from 'react-native';

import HomeScreen from './src/screens/HomeScreen';
import AzkarScreen from './src/screens/AzkarScreen';
import TasbihScreen from './src/screens/TasbihScreen';
import QiblaScreen from './src/screens/QiblaScreen';
import SettingsScreen from './src/screens/SettingsScreen';

I18nManager.forceRTL(true);

const Tab = createBottomTabNavigator();

const COLORS = {
  primary: '#C9A84C',
  background: '#1A1A2E',
  card: '#16213E',
  text: '#FFFFFF',
  inactive: '#666',
};

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.background} />
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;
            if (route.name === 'الرئيسية') iconName = focused ? 'home' : 'home-outline';
            else if (route.name === 'الأذكار') iconName = focused ? 'book' : 'book-outline';
            else if (route.name === 'التسبيح') iconName = focused ? 'radio-button-on' : 'radio-button-off';
            else if (route.name === 'القبلة') iconName = focused ? 'compass' : 'compass-outline';
            else if (route.name === 'الإعدادات') iconName = focused ? 'settings' : 'settings-outline';
            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: COLORS.primary,
          tabBarInactiveTintColor: COLORS.inactive,
          tabBarStyle: { backgroundColor: COLORS.card, borderTopColor: '#333' },
          headerStyle: { backgroundColor: COLORS.background },
          headerTintColor: COLORS.primary,
          headerTitleAlign: 'center',
        })}
      >
        <Tab.Screen name="الرئيسية" component={HomeScreen} />
        <Tab.Screen name="الأذكار" component={AzkarScreen} />
        <Tab.Screen name="التسبيح" component={TasbihScreen} />
        <Tab.Screen name="القبلة" component={QiblaScreen} />
        <Tab.Screen name="الإعدادات" component={SettingsScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
